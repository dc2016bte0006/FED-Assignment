import Dispatcher from '../dispatcher/Dispatcher'
import * as ActionTypes from '../actions/ActionTypes'
import {EventEmitter} from 'events'
import _ from 'lodash'

let _songs=[]

class SongStoreClass extends EventEmitter{
    addChangeListener(cb){
        this.on('change',cb)
    }

    removeChangeListener(cb){
        this.removeListener('change',cb)
    }

    emitChange(){
        this.emit('change')
    }

    getAllSongs(){
        return _songs
    }
}

let SongStore = new SongStoreClass()
export default SongStore

Dispatcher.register(action => {
    switch(action.actionType){
        case ActionTypes.INITIALIZE: 
             _songs = action.songs;
            SongStore.emitChange()
            break
        
        case ActionTypes.ADD_SONG:
            _songs.push(action.song)
            SongStore.emitChange()
            break
        
        default:

    }
})