import React from 'react'
import './App.css';

import Header from './components/Header';
import About from './components/About'

import {
  NavLink,
  Route,
  BrowserRouter as Router,
  Switch,
  useLocation,
} from "react-router-dom";
import AllSongs from './components/AllSongs';
import AddSong from './components/AddSong'
import SongPage from './components/SongPage'


function onPaths(paths) {
  return(match, location) => {
    return paths.includes(location.pathname)
  }
}

function App() {
  return (
    <div className="App">
      <Header />
      <Router>
        <nav>
        <NavLink exact to="/" activeStyle={{color:"red"}}>
            <span className="Link1">About</span>
          </NavLink>
          <NavLink 
            	exact to='/songs'  activeStyle={{color:"red"}} isActive={onPaths(["/songs","/addSong","/SongPage/"])}>
                Songs
            </NavLink> 
        </nav>

        <Switch>
        <Route exact path="/" component={About} />
        <Route exact path="/songs" component={AllSongs} />
        <Route exact path="/SongPage/:id" component={SongPage} />
        <Route exact path="/addSong" component={AddSong} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
