import React, { Component } from 'react'
import SongData from './SongData'
import _ from 'lodash'
import axios from 'axios'


// let currentId = SongData.songs.length
// const _clone = function(item) {
//     return JSON.parse(JSON.stringify(item))
// }

export class SongApi{
    static getAllSongs(cb){
        // return _clone(SongData.songs)
        axios.get('http://localhost:3001/mysongs').
        then(res => 
        cb(res.data))
        .catch(error => { throw error})

    }
    // static addSong(song){
    //     currentId = currentId + 1
    //     song.id = currentId
    //     SongData.songs.push(song)
    //     return _clone(song)
    // }

    static addSong(song){
        axios.post("http://localhost:3001/mysongs",song)
        .then(result=>{
            console.log(result)
        })
    }
}

export default SongApi
