export default{
    "songs": [
      {
        "id": 1,
        "movie": "Ae Dil Hai Mushkil",
        "title": "Ae Dil Hai Mushkil",
        "length": "3:45",
        "singer": "Arijit Singh"
      },
      {
        "id": 2,
        "movie": "Shershaah",
        "title": "Raatan Lambiya",
        "length": "3:50",
        "singer": "Jubin Nautiyal"
      },
      {
        "id": 3,
        "movie": "Criminal",
        "title": "Tum Mile Dil Khile",
        "length": "3:50",
        "singer": "Kumar Sanu"
      },
      {
        "id": 4,
        "movie": "Shershaah",
        "title": "Ranjha",
        "length": "3:43",
        "singer": "Jasleen Royal"
      }
    ]
  }