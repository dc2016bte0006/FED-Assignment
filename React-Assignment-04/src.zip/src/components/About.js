import React, { Component } from 'react'

export class About extends Component {
    render() {
        return (
            <div>
               <h4 >About Page displays the Song List</h4>
               <hr />
            </div>
        )
    }
}

export default About
