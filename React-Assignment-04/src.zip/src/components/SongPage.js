import { Card} from "react-bootstrap";

function SongPage(props) {
  return (
    <div>
      <Card style={{ width: "25rem", paddingLeft: "25rem", border:"1"}}>
        <Card.Body>
          <Card.Title><h4>Song Details</h4></Card.Title>
          <hr />
          <Card.Text>
            <p>Id of the Song is: {props.location.state.id}</p>
            <p>Id of the Song is: {props.location.state.movie}</p>
            <p>Id of the Song is: {props.location.state.length}</p>
            <p>Id of the Song is: {props.location.state.singer}</p>
          </Card.Text>
        </Card.Body>
      </Card>
    </div>
  );
}

export default SongPage;
