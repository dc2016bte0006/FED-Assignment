import React, { Component , useHistory} from 'react'
import {Link, NavLink} from 'react-router-dom'
import SongList from './SongList'
import  SongStore from '../stores/SongStore'
import InitializeActions from '../actions/InitializeActions'
import SongApi from '../data/SongApi'




class AllSongs extends Component {
    constructor(props) {
        super(props)
    
        this._onChange = this._onChange.bind(this)
        
        this.state = {
            //songs : SongStore.getAllSongs(),
            // error: null,
            // isLoaded: false,
            songs: []
        }

    }
    
    
    componentDidMount(){
        SongStore.addChangeListener(this._onChange)
        SongApi.getAllSongs(data => this.setState({songs: data}))
        InitializeActions.initSongs()
        
    //    fetch('http://localhost:3001/mysongs')
    //    .then(res=>res.json())
    //    .then((result)=>{
    //        this.setState({
    //            isLoaded: true,
    //            songs: result
    //        })
    //    },
    //    (error) => {
    //        this.setState({
    //            isLoaded: true,
    //            error
    //        })
    //    }
    //    )
    }


    componentWillUnmount(){
        SongStore.removeChangeListener(this._onChange)
    }

    _onChange(){
        this.setState({
            songs: SongStore.getAllSongs()
        })
    }
   
    
    render() {
       
        return (
            <div>
               <h3>All Songs</h3>
               <SongList songs={this.state.songs} />
               <NavLink to="/addSong"><button type="button">Add Song</button></NavLink>
            </div>
        )
    }
}

export default AllSongs
