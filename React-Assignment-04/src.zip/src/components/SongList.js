import React, { Component } from 'react'
import SongDetail from './SongDetail'


export class SongList extends Component {
    render() {
        var songNodes = this.props.songs.map(song => {
            return (
                <SongDetail key={song.id} id={song.id} movie={song.movie} title={song.title}
                length={song.length} singer={song.singer} />
            )
        })
        
        

        return (
            <div>
                <table border="1">
                    <thead>
                        <tr>
                            <th>Movie</th>
                            <th>Title</th>
                            <th>Length</th>
                            <th>Singer</th>
                        </tr>
                    </thead>
                    <tbody>
                        {songNodes}
                        
                    </tbody>
                </table>
            </div>
        )
    }
}

export default SongList
