import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import SongForm from './SongForm'
import SongActions from '../actions/SongActions'

export class AddSong extends Component {
    constructor(props) {
        super(props)
        this.saveSong = this.saveSong.bind(this)
    }

    saveSong(song){
        SongActions.addSong(song)
        this.props.history.push('/songs')
    }
    
    render() {
        return (
            <SongForm onSave={this.saveSong}/>
        )
    }
}

export default withRouter(AddSong)
