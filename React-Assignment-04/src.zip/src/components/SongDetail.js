import React, { useState } from "react";
import { Link, Prompt } from "react-router-dom";

function SongDetail(props) {
  const [clicked, setClicked] = useState(false);
  return (
    <tr>
      <td onMouseEnter={()=>{setClicked(true)}}
      onMouseLeave={()=>{setClicked(false)}}>
        <Link to={{ pathname: `/SongPage/${props.id}`,state:{id:props.id,movie:props.movie,length:props.length,singer:props.singer} }}>{props.movie}</Link>
      </td>
      <td>{props.title}</td>
      <td>{props.length}</td>
      <td>{props.singer}</td>
      <Prompt when={clicked} message="Are you sure you want to view the details of song?"/>
    </tr>
  );
}

export default SongDetail;
