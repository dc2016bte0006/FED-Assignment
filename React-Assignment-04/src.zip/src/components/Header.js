import React from 'react'

function Header() {
    return (
        <div>
            <h3 style={{color: "#FF00E4"}}>FED React: Assignment4: Router Transition, Flux Pattern, Formik, Yup</h3>
            <hr />
            
        </div>
    )
}

export default Header
