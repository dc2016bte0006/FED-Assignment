import Dispatcher from '../dispatcher/Dispatcher'

import SongApi from '../data/SongApi'
import * as ActionTypes from './ActionTypes'

export default class SongActions{
    static addSong(song){
        let newSong = SongApi.addSong(song)
        console.log("Adding new Song")
        Dispatcher.dispatch({
            actionType : ActionTypes.ADD_SONG,
            song: newSong
        })
    }
}