import Dispatcher from "../dispatcher/Dispatcher";
import SongApi from "../data/SongApi";
import * as ActionTypes from './ActionTypes'

export default class InitializeActions {
    static initSongs() {
        // const initialSongs = SongApi.getAllSongs()

        // Dispatcher.dispatch({
        //     actionType : ActionTypes.INITIALIZE,
        //     songs: initialSongs

        SongApi.getAllSongs(data=>
            Dispatcher.dispatch({
                ActionTypes:ActionTypes.INITIALIZE,
                songs:data
            })
        )
    }
}