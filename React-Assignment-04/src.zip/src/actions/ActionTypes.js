export const INITIALIZE = 'INITIALIZE'
export const ADD_SONG = 'ADD_SONG'