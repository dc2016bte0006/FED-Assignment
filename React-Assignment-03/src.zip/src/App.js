import React, {useEffect, useState} from 'react'
import './App.css';
import Header from './components/Header';
import {NavLink,Route, BrowserRouter as Router} from 'react-router-dom'
import About from './components/About'
import AllSongs from './components/AllSongs'

function App() {
  const [songs, setSongs] = useState(null)

    useEffect(() => {
        fetch('http://localhost:3001/mysongs')
        .then(res =>{
            return res.json()
        })
        .then((data)=>{
            console.log(data)
            setSongs(data)
        })
    }, [])

  return (
    <div className="App">
      <Header />
    <Router>
      <span className="Link1"><NavLink exact to="/" activeClassName="about-active">About</NavLink></span>
      <span><NavLink exact to="/songs" activeClassName="about-active">Songs</NavLink></span>


      <Route exact path="/"><About/></Route>
      <Route exact path="/songs">{songs && <AllSongs songs={songs}/>}</Route>
    </Router>

    
    </div>
  );
}

export default App;
