import React from 'react'
import './allsongs.css'

function AllSongs({songs}) {

    return (
        <div className="AllSongs">
            <h6>Songs List</h6>
            <table border="1">
                <tr>
                    <th>Movie</th>
                    <th>Title</th>
                    <th>Song Length</th>
                    <th>Singer</th>
                </tr>
                
                   
                    {songs.map((song)=>(
                        <tr>
                            <td>{song.movie}</td>
                            <td>{song.title}</td>
                            <td>{song.length}</td>
                            <td>{song.singer}</td>
                        </tr>
            ))}
                    
                
    
            </table>
            
        </div>
    )
}

export default AllSongs
