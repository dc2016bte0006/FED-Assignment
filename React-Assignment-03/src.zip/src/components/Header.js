import React from 'react'
import "./header.css"

function Header() {
    return (
        <div>
            <h4>FED React : Assignment3 : Router, JSON Server</h4>
            <hr />
            <h5>Display Songs from JSON Server</h5>
            <hr />
        </div>
    )
}

export default Header
