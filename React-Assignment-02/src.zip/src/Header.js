import React from 'react'
import './css/Header.css'

function Header() {
    return (
        <div>
            <h3>FED React : Assignment2 : Multiple Components, JSON</h3>
        </div>
    )
}

export default Header
