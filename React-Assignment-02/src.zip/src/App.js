import React, { Component } from 'react'
import AllSongs from './AllSongs'
import Header from './Header'
import Playlist from './Playlist'


export class App extends Component {
  render() {
    return (
      <div>
        <Header />
        <hr />
        <AllSongs>
          {(items,addItem)=>(
            <Playlist items={items} addItem={addItem} />
          )}
        </AllSongs>
      </div>
    )
  }
}

export default App
