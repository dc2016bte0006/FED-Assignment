import React, { Component } from "react";
import './css/allsongs.css'

export class AllSongs extends Component {
  constructor(props) {
    super(props);

    this.state = {
      mysongs: [
        {
          movie: "Ae Dil Hai Mushkil",
          title: "Ae Dil Hai Mushkil",
          length: "3:45",
          singer: "Arijit Singh",
        },
        {
            movie: "Shershaah",
            title: "Raatan Lambiya",
            length: "3:50",
            singer: "Jubin Nautiyal",
          },
          {
            movie: "Criminal",
            title: "Tum Mile Dil Khile",
            length: "3:50",
            singer: "Kumar Sanu",
          },
      ],
    };
  }
  addItem = (newItem) => {
      this.setState(prevState => {
          return {mysongs : [...prevState.mysongs, newItem]}
      })
  }

  render() {
    return <div>
        <h4>Display Song Info using in memory JSON</h4>
        <h6>Number of songs in playList: {this.state.mysongs.length}</h6>
        <hr />
        {this.props.children(this.state.mysongs, this.addItem)}
    </div>;
  }
}

export default AllSongs;
