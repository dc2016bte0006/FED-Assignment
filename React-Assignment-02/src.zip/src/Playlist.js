import React, { Component } from 'react'
import './css/playlist.css'

export class Playlist extends Component {
    constructor(props) {
        super(props)
        this.onSubmit = this.onSubmit.bind(this)    
    }
    onSubmit(event){
        event.preventDefault();
        var newItem = {};
        newItem.movie = this.refs.movie.value;
        newItem.title = this.refs.title.value;
        newItem.length = this.refs.length.value;
        newItem.singer = this.refs.singer.value;
        this.props.addItem(newItem)
        this.refs.movie.value=''
        this.refs.title.value=''
        this.refs.length.value=''
        this.refs.singer.value=''
        
    }
    
    render() {
        const {items} = this.props;
        let itemList = items.map((song) =>(
            <tr>
                <td>{song.movie}</td>
                <td>{song.title}</td>
                <td>{song.length}</td>
                <td>{song.singer}</td>
            </tr>
        ))
        return (
            <div className="playlist">
                <h5>SongsList</h5>
                <table border='1'>
                    <tr>
                        <th>Movie</th>
                        <th>Title</th>
                        <th>Song Length</th>
                        <th>Singer</th>
                    </tr>
                    {itemList}
                </table>
                <form action="">
                    <input type="text" ref="movie" /> Movie <br />
                    <input type="text" ref="title" /> Title <br />
                    <input type="text" ref="length" /> Song Length <br />
                    <input type="text" ref="singer" /> Singer <br />
                    <input type="submit" value="Add Song" onClick={this.onSubmit}/>
                </form>
            </div>
        )
    }
}

export default Playlist
