import React from 'react'
import './css/Header.css'

function Header() {
    return (
        <div className="header">
            <h3>FED React : Assignment1 : State, Event Handling</h3>
        </div>
    )
}

export default Header
