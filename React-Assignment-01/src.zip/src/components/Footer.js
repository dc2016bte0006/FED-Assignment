import React from 'react'
import './css/Footer.css'

function Footer(props) {
    return (
        <div>
            <h3>{props.ptr}</h3>
        </div>
    )
}

export default Footer
