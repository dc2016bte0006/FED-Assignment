import React, { Component } from "react";
import Footer from "./Footer";
import './css/Content.css'


class Content extends Component {
    constructor() {
        super()

        const img1 = require('../images/img01.jpg').default;
        const img2 = require('../images/img02.jpg').default;
        const img3 = require('../images/img03.jpg').default;
    
        this.state = {
             index: 0,
             imgList: [img1,img2,img3],
        }
    }

    prevImage(){
        if(this.state.index -1 === -1){
            this.setState({
                index: this.state.imgList.length - 1
            })
        }
        else{
            this.setState({
                index: this.state.index - 1
            })
        }
    }

    nextImage(){
        if(this.state.index + 1 === this.state.imgList.length){
            this.setState({
                index: 0
            })
        }
        else{
            this.setState({
                index: this.state.index + 1
            })
        }
    }

       
    
  render() {
    return (
      <div class="content">
         <button onClick={()=>this.nextImage()}>Next</button>
        <img src={this.state.imgList[this.state.index]} alt=""  width="150px"/>
        <button onClick={()=>this.prevImage()}>Previous</button>
        <div>
            <Footer ptr ={this.state.index} />
        </div>
      </div>
    );
  }
}

export default Content;
