import React from 'react'
import "./header.css"

function Header() {
    return (
        <div>
            <h4>FED React : Assignment5 : Functional Components, Hooks</h4>
            <hr />
            <h5>Display Song Info from the JSON Server</h5>
            <hr />
        </div>
    )
}

export default Header
