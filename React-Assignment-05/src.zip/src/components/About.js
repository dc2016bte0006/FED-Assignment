import React from 'react'
import './about.css'

function About() {
    return (
        <div className="About">
           <h2>About Page (using Functional Component) : This app displays the Song List</h2>
        </div>
    )
}

export default About
