import React, {useEffect, useState} from 'react'
import './App.css';
import Header from './components/Header';
import {NavLink,Route, BrowserRouter as Router,Switch} from 'react-router-dom'
import About from './components/About'
import AllSongs from './components/AllSongs'

function App() {
  const [songs, setSongs] = useState(null)

    useEffect(() => {
        fetch('http://localhost:3001/mysongs')
        .then(res =>{
            return res.json()
        })
        .then((data)=>{
            console.log(data)
            setSongs(data)
        })
    }, [])

  return (
    <div className="App">
      <Header />
    <Router>
      <nav className="nav">
        <NavLink exact to="/" activeClassName="about-active" className="Link1">About</NavLink>
        <NavLink to="/songs" activeClassName="about-active">Songs</NavLink>
      </nav>


      <Switch>
      <Route exact path="/"><About/></Route>
      <Route path="/songs">{songs && <AllSongs songs={songs}/>}</Route>
      </Switch>
    </Router>

    
    
    </div>
  );
}

export default App;
