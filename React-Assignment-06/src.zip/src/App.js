import React from "react";
import "./App.css";
import {
  NavLink,
  Route,
  BrowserRouter as Router,
  Switch,
  useLocation,
} from "react-router-dom";

import "bootstrap/dist/css/bootstrap.min.css";
import Header from "./components/Header";
import About from './components/About'
import AllSongs from './components/AllSongs'
import AddSongForm from './components/AddSongForm'


function onPaths(paths) {
  return (match, location) => {
    return paths.includes(location.pathname);
  };
}

function App() {
  return (
    <div className="App" >
      <Header />
      <Router>
        <NavLink exact to="/" activeStyle={{ color: "red" }}>
          <span className="Link1">About</span>
        </NavLink>

        <NavLink
          exact
          to="/songs"
          activeStyle={{ color: "red" }}
          isActive={onPaths(["/songs", "/add"])}
        >
          Songs
        </NavLink>

        <Switch>
          <Route exact path="/" component={About} />
          <Route exact path="/songs" component={AllSongs} />
  
          <Route exact path="/add" component={AddSongForm} />
         
        </Switch>
      </Router>
    </div>
  );
}

export default App;
