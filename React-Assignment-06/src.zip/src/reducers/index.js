import { combineReducers } from "redux";
import songs from './SongReducers'

export default combineReducers({
    songs
})