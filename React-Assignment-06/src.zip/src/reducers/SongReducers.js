import {
    ADD_SONG,
    GET_SONGS
} from '../actions/types'

const initialState = []

function songReducer(songs = initialState, action){
    const { type, payload } = action

    switch(type){
        case ADD_SONG:
            return [...songs, payload];
        
        case GET_SONGS:
            return payload;

        default:
            return songs;
    }
}

export default songReducer;