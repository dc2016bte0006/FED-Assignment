import http from '../http-common'

class SongService {
    getAll(){
        return http.get("/mysongs");
    }

    create(data){
        return http.post("/mysongs",data);
    }
}

export default new SongService();