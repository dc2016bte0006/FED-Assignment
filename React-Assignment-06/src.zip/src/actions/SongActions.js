import {
    ADD_SONG,
    GET_SONGS
  } from "./types";
  
  import SongService from '../services/SongService'
  
  export const addSong = (movie, title, length, singer) => async (dispatch) => {
    try {
      const res = await SongService.create({ movie, title, length, singer });
  
      dispatch({
        type: ADD_SONG,
        payload: res.data,
      });
  
      return Promise.resolve(res.data);
    } catch (err) {
      return Promise.reject(err);
    }
  };
  
  export const getSongs = () => async (dispatch) => {
    try {
      const res = await SongService.getAll();
  
      dispatch({
        type: GET_SONGS,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };
  
  