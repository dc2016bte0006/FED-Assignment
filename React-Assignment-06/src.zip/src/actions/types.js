export const ADD_SONG = "ADD_SONG";
export const GET_SONGS = "GET_SONGS";
