import React from 'react'

function About() {
    return (
        <div className="container-fluid">
            <h4 style={{paddingTop: "1rem"}}>About Page : This app displays the Song List using React-Redux</h4>
        </div>
    )
}

export default About
