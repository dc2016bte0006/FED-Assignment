import React, { Component } from 'react'
import {connect} from 'react-redux'

import { getSongs} from '../actions/SongActions'
import {NavLink} from 'react-router-dom'

export class AllSongs extends Component {

    constructor(props) {
        super(props)
    
        this.state = {
             
        }
    }

    componentDidMount(){
        this.props.getSongs();
    }
    
    render() {

        const {songs} = this.props

        return (
            <div className="container-fluid" style={{paddingTop:"1rem"}}>
                <h5>Songs List - Using Redux</h5>
                <table className="table table-striped">
                    <thead className="thead-dark">
                        <th>Movie</th>
                        <th>Title</th>
                        <th>Length</th>
                        <th>Singer</th>
                    </thead>

                    <tbody>
                        {songs && songs.map((song) => (
                            <tr>
                                <td>{song.movie}</td>
                                <td>{song.title}</td>
                                <td>{song.length}</td>
                                <td>{song.singer}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <NavLink to="/add"><button type="button">Add Song</button></NavLink>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
      songs: state.songs,
    };
  };

export default connect(mapStateToProps,{
    getSongs
})(AllSongs);
