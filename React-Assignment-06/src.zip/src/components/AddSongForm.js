import React, { useState } from "react";
import { useFormik } from "formik";
import * as yup from "yup";
import {Prompt} from "react-router-dom"
import {connect} from 'react-redux'
import {addSong} from '../actions/SongActions'

function AddSongForm(props) {
  const [changed, setChanged] = useState(false);
  const formik = useFormik({
    initialValues: {
      movie: "",
      title: "",
      length: "",
      singer: "",
    },
    validationSchema: yup.object({
      movie: yup.string().required("Movie name is required"),
      title: yup.string().required("Title is required"),
      length: yup.string().required("Song Length is required"),
      singer: yup.string().required("Singer Name is required"),
    }),
    onSubmit: (values) => {
      var song = {};
      song.movie = values.movie;
      song.title = values.title;
      song.length = values.length;
      song.singer = values.singer;
      props.addSong(song.movie, song.title, song.length, song.singer)
      props.history.push('/songs')
    },
  });
  return (
    <div>
      <form action="" onSubmit={formik.handleSubmit} className="form">
     
      <div className="container-fluid">
      <h5 style={{paddingTop:"1rem"}}>Add Song - Using Redux</h5>
      <table className="table">
        <tr>
          <td><h6>Movie</h6></td>
          <td>
            <input type="text" id="movie" name="movie" onChange={formik.handleChange} value={formik.values.movie}/>
            {formik.errors.movie?<spam style={{color:"red", paddingLeft:"1rem"}}>{formik.errors.movie}</spam>:null}
          </td>
        </tr>
        <tr>
          <td><h6>Title</h6></td>
          <td>
            <input type="text" id="title" name="title" onChange={formik.handleChange} value={formik.values.title}/>
            {formik.errors.title?<spam style={{color:"red" , paddingLeft:"1rem"}}>{formik.errors.title}</spam>:null}
          </td>
        </tr>
        <tr>
          <td><h6>Length</h6></td>
          <td>
            <input type="text" id="length" name="length" onChange={formik.handleChange} value={formik.values.length}/>
            {formik.errors.length?<spam style={{color:"red" , paddingLeft:"1rem"}}>{formik.errors.length}</spam>:null}
          </td>
        </tr>
        <tr>
          <td><h6>Singer</h6></td>
          <td>
            <input type="text" id="singer" name="singer" onChange={formik.handleChange} value={formik.values.singer}/>
            {formik.errors.singer?<spam style={{color:"red" , paddingLeft:"1rem"}}>{formik.errors.singer}</spam>:null}
          </td>
        </tr>
        
        <tr>
         <button type="submit" onClick={()=>{setChanged(true)}}>Submit</button>
        </tr>
      </table>
      </div>
    </form>
    <Prompt when={!changed}
    message="Are you sure you want to exit without saving?"></Prompt>
    </div>
   
  );
}

export default connect(null,{addSong})(AddSongForm)
