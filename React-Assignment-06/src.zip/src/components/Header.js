import React from 'react'

function Header() {
    return (
        <div class="container-fluid">
            <h3 style={{color: "#FF00E4"}}>FED React: Assignment6: React Redux</h3>
            <hr />
            
        </div>
    )
}

export default Header
